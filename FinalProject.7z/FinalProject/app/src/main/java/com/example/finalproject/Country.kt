package com.example.finalproject

data class Country(
    val Country: String,
    val ISO2: String,
    val Slug: String
)